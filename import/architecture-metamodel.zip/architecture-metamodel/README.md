# Architecture Metamodel

Static, JSON-driven, single-page mind-map of architecture documents. Drop one JSON per account into `data/`, point the page at it, and the tree renders. No Python, no Node, no server runtime — pure HTML/CSS/JS.

## Run locally

```bash
# from the repo root
python -m http.server 8000
# open http://localhost:8000/
```

`fetch()` requires the page to be served (not `file://`), so any static server works: `python -m http.server`, `npx serve .`, IIS, nginx, GitHub Pages, SharePoint document library, Adobe EDS, etc.

## Authoring an account

Each account is one JSON file in `data/<id>.json`. Schema:

```jsonc
{
  "title": "Omnicom",                      // root node label
  "description": "...",                    // optional
  "owner": "atul.jadhav@adobe.com",        // cascades to descendants
  "children": [
    { "title": "NSTA", "children": [
      {
        "title": "2025",
        "url": "https://adobe.sharepoint.com/...",
        "internal": true,
        "reviewed": false,
        "description": "..."
      }
    ]},
    {
      "title": "Global Admin Console",
      "side": "left",                      // root's direct child can be pinned to the left side
      "children": [ { "title": "Consolidated", "children": [] } ]
    },
    {
      "title": "Account Overview",
      "url": "https://lucid.app/...",
      "internal": true,
      "reviewed": true,
      "audience": "client"                 // when not internal: "client" | "internal" | "public"
    }
  ]
}
```

**Rules**

- A node is a **leaf** if it has a `url` (or has no `children` array). Otherwise it's a folder.
- Required: `title`. Everything else optional.
- `owner` cascades. Set once at root, override anywhere.
- `side: "left" | "right"` — applies to direct children of the root only. Controls which side of the trunk the branch sits on. Default: leaves left, folders right.
- `status: "complete" | "in-progress" | "not-started"` — leaves only. Drives the leaf border color (green / amber / red) and the topbar completeness ring. Defaults to `not-started`.
- `internal: true` shows the 🔒 badge. `internal: false` shows 🌐 (with `audience: "client"` it reads "External (client only)").
- `reviewed: true` shows the ✓ badge.
- Tags (`"tags": ["foo","bar"]`) — surfaced in the popup; reserved for filtering in v2.

The topbar **completeness ring** is recomputed on every page load. Formula:
`(complete + 0.5 × in-progress) / total leaves`. Hover the ring for the breakdown.

After editing, **hard-refresh the browser** (Ctrl+F5) to see changes.

## Adding a new account (e.g. Accenture)

1. Create `data/accenture.json` with the schema above (copy `data/omnicom.json` as a template).
2. Add an entry to `data/_accounts.json`:
   ```json
   {
     "accounts": [
       { "id": "omnicom",   "title": "Omnicom",   "file": "omnicom.json" },
       { "id": "accenture", "title": "Accenture", "file": "accenture.json" }
     ],
     "default": "omnicom"
   }
   ```
3. Refresh — the topbar dropdown lists both accounts.

URL is bookmarkable: `…/index.html?account=accenture` opens straight to that account.

## Importing from a folder structure (optional)

If you have an existing folder hierarchy with per-folder `_meta.yml` files, bulk-convert it to JSON in one shot:

```bash
pip install -r requirements.txt                  # only needs pyyaml
python tools/migrate.py /path/to/Accenture accenture   # → data/accenture.json
```

The script also adds/updates the entry in `data/_accounts.json`.

## Deploying

Any static host works. You're shipping these files only:

```
index.html
app.js
styles.css
data/
  _accounts.json
  omnicom.json
  ...
```

| Target | Steps |
|---|---|
| **SharePoint document library** | Upload the folder; share the URL of `index.html`. SharePoint serves static HTML directly. |
| **Adobe EDS** | Drop into the EDS-backed Git repo. Fits the static model perfectly. |
| **GitHub Pages / Netlify / internal nginx** | Push, point at the directory, done. |
| **Email a zip** | Recipient unzips, runs `python -m http.server` in the folder, opens localhost. |

CDN dependencies: `d3@7` and `fuse.js@7` are loaded from `cdn.jsdelivr.net`. For air-gapped hosting, download those two files and update the `<script src>` paths in `index.html`.

## Layout

```
architecture-metamodel/
├── index.html               ← entry, drop on any static host
├── app.js                   ← graph renderer + normalizer + account picker + completeness ring
├── styles.css               ← light mind-map theme tokens + status colors
├── data/
│   ├── _accounts.json       ← picker manifest
│   └── omnicom.json         ← hand-authorable source of truth
├── tools/
│   └── migrate.py           ← optional: convert any _meta.yml folder tree → JSON
├── docs/
│   └── UI-PLAN.md           ← visual system reference
├── requirements.txt         ← pyyaml (migrate.py only — runtime SPA needs nothing)
└── README.md
```

## Tech notes

- **Renderer**: D3 v7 (tree + radial layouts, zoom/pan, transitions).
- **Search**: Fuse.js fuzzy across title / description / owner / status.
- **Layout**: vertical green trunk; root's direct children sit on alternating sides; each subtree extends outward (right grows further right, left grows further left).
- **Status**: every leaf carries a `status` field (`complete | in-progress | not-started`). Border color, status dot, and the connector tint to that leaf all read from it.
- **No build step**. Single `app.js`, hand-readable.
- **CDN deps**: `d3@7`, `fuse.js@7`, Inter + JetBrains Mono fonts. For air-gapped hosting, vendor those locally and update the `<link>` / `<script>` URLs in `index.html`.
