"""Convert a folder hierarchy with per-folder `_meta.yml` files into a single
hand-authorable JSON file (`data/<account>.json`) for the static SPA.

Usage:
    python tools/migrate.py <source-folder> [account-id]

Example:
    python tools/migrate.py /path/to/Accenture accenture   # → data/accenture.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import yaml

META_FILE = "_meta.yml"
SKIP = {META_FILE, ".DS_Store", "Thumbs.db"}


def _read_meta(folder: Path) -> dict[str, Any]:
    p = folder / META_FILE
    if not p.is_file():
        return {}
    try:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return {}


def _drop_none(d: dict[str, Any]) -> dict[str, Any]:
    """Strip keys with None / False / [] / '' values to keep the JSON tidy.

    Keep `children` even when [] (empty subtree is meaningful — it forces
    the node to render as a folder, not a leaf).
    """
    out: dict[str, Any] = {}
    for k, v in d.items():
        if v is None:
            continue
        if k != "children" and v in (False, "", []):
            continue
        out[k] = v
    return out


def _walk(folder: Path) -> dict[str, Any]:
    meta = _read_meta(folder)
    items = meta.get("items") or {}

    node: dict[str, Any] = {
        "title": str(meta.get("title") or folder.name),
        "description": meta.get("description"),
        "owner": meta.get("owner"),
        "side": meta.get("side"),
    }

    entries = sorted(
        [e for e in folder.iterdir() if e.name not in SKIP and not e.name.startswith(".")],
        key=lambda e: (not e.is_dir(), e.name.lower()),
    )

    children: list[dict[str, Any]] = []
    for entry in entries:
        if entry.is_dir():
            sub = _walk(entry)
            override = items.get(entry.name + "/") or items.get(entry.name) or {}
            sub_meta = _read_meta(entry)
            for k in ("title", "description", "owner", "side"):
                if not sub_meta.get(k) and override.get(k):
                    sub[k] = override[k]
            children.append(_drop_none(sub))
        elif entry.is_file():
            item = items.get(entry.name) or {}
            reviewed = bool(item.get("reviewed", False))
            # Default status: explicit `status` if set, else reviewed→complete, else not-started
            default_status = "complete" if reviewed else "not-started"
            leaf: dict[str, Any] = {
                "title": str(item.get("title") or entry.stem),
                "description": item.get("description"),
                "owner": item.get("owner"),
                "internal": bool(item.get("internal", False)),
                "reviewed": reviewed,
                "audience": item.get("audience"),
                "status": item.get("status") or default_status,
                "url": item.get("url"),
                "tags": item.get("tags") or [],
                "side": item.get("side"),
            }
            children.append(_drop_none(leaf))

    node["children"] = children
    return _drop_none(node)


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("usage: python tools/migrate.py <source-folder> [account-id]", file=sys.stderr)
        return 2
    src = Path(args[0])
    account_id = args[1] if len(args) >= 2 else src.name.lower()

    if not src.is_dir():
        print(f"error: source folder not found: {src}", file=sys.stderr)
        return 2

    tree = _walk(src)
    out_path = Path("data") / f"{account_id}.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(tree, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote {out_path}")

    # Also refresh the picker manifest so the new account is selectable.
    manifest_path = Path("data") / "_accounts.json"
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    else:
        manifest = {"accounts": [], "default": account_id}
    accounts = {a["id"]: a for a in manifest.get("accounts", [])}
    accounts[account_id] = {
        "id": account_id,
        "title": tree.get("title", account_id.title()),
        "file": f"{account_id}.json",
    }
    manifest["accounts"] = sorted(accounts.values(), key=lambda a: a["title"].lower())
    manifest.setdefault("default", account_id)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"updated {manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
