# UI Plan — Architecture Metamodel

Companion to the [project plan](../../../Users/atuljadhav/.claude/plans/c-users-atuljadhav-downloads-blank-diag-hashed-anchor.md). This doc owns visual language, layout, components, states, motion, and accessibility — the *how it looks and feels* layer. Engineering shape (stack, generator, server) lives in the project plan.

---

## 1. Design intent

| Pillar | Decision |
|---|---|
| Mood | Professional, calm, "command-center" — closer to Linear / Vercel / Adobe Spectrum dark than to a marketing site. |
| Density | Information-dense but breathable. Single-screen experience; no scrollable page chrome. |
| Hierarchy cue | Depth communicated by **node shape, accent color, and connector weight**, not by font size. |
| Motion | Functional, never decorative. Used to preserve spatial continuity (where did that node go?), max ~280 ms. |
| Personality | One subtle accent (gradient logo dot, hover glow). No skeuomorphism, no shadows on flat surfaces. |

---

## 2. Visual system (design tokens)

Already wired in [src/styles.css](../src/styles.css) under `:root`. Keep adjustments centralized there.

### 2.1 Color

| Token | Hex | Usage |
|---|---|---|
| `--bg-0` | `#0b0f17` | App canvas (radial-gradient base) |
| `--bg-1` | `#111826` | Topbar, search input, chip resting |
| `--bg-2` | `#1a2332` | Folder node fill, popup body |
| `--bg-3` | `#243144` | Leaf node fill, active toggle segment |
| `--border` | `#2a3850` | All 1 px dividers + node strokes |
| `--text` | `#e6edf6` | Primary text |
| `--text-dim` | `#8a99b3` | Secondary text, breadcrumbs |
| `--text-faint` | `#5a6b85` | Mono captions, separators |
| `--accent` | `#6aa9ff` | Primary action, focus ring, folder hover |
| `--accent-2` | `#8b6aff` | Gradient pair (logo, primary CTA) |
| `--accent-3` | `#5dd6c4` | Leaf hover glow (different from folder so type is readable at a glance) |
| `--good` | `#3ecf8e` | "Reviewed" badge |
| `--warn` | `#f5b86a` | "Internal" badge, search-match outline |
| `--danger` | `#ff6b6b` | Reserved for errors |

Contrast: all text/background pairs ≥ WCAG AA on the dark canvas.

### 2.2 Typography

- Sans: system stack (`-apple-system, "Segoe UI", Roboto, ...`) — fast, neutral, OS-native.
- Mono: system mono stack — used for paths, owners, badges, metadata keys (gives a "data" feel without picking a brand font).
- Scale: 11 (badge/caption) · 12 (chips, sub-labels) · 13 (popup body) · 14 (base) · 15 (brand) · 18 (popup title). No headings >18 — the graph is the headline.

### 2.3 Spacing & radius

- Base unit 4 px. Common values: 6, 8, 10, 14, 22.
- Radii: 6 (chip), 8 (input/button), 10 (panel), 14 (popup), 999 (pill/badge).
- Strokes: 1.0–1.2 px. Selected/highlight nodes step to 1.8 px.

### 2.4 Elevation

Two levels only:
- **Resting** — flat, 1 px border.
- **Floating** — popup: `0 18px 48px rgba(0,0,0,0.55)` + soft inner gradient on bg.

Hover uses a **glow** (`drop-shadow` with accent color at 45 % alpha), not a lift. Glow communicates interactivity better in a dark canvas than shadow.

---

## 3. Screen layout

Single page, three rows, no overflow scroll.

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ●  Architecture Metamodel  [Omnicom]      🔍 search   chips  Tree|Radial│   ← topbar  (auto height)
├─────────────────────────────────────────────────────────────────────────┤
│  Omnicom › Architecture › FY26                                          │   ← breadcrumb (auto height)
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│                                                                         │
│                          [   GRAPH CANVAS   ]                           │   ← 1fr; SVG with pan/zoom
│                                                                         │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
        ┌──────── popup overlay (modal, centered) ────────┐
```

CSS grid: `grid-template-rows: auto auto 1fr;`. Body has `overflow: hidden` so only the graph scrolls (via zoom/pan).

### 3.1 Topbar (height ~56 px)

- **Left:** logo dot (gradient) → app name → account chip (`Omnicom`).
- **Right (in order):** search input · filter chips (Reviewed only, Internal only) · layout toggle (Tree | Radial).
- Background: translucent `rgba(11,15,23,0.7)` with `backdrop-filter: blur(8px)` — gives a clean separation from the canvas without a hard line.

Responsive: below ~960 px, the right cluster wraps under the brand on a second line; below ~640 px, search becomes full-width and chips collapse into an icon-only "Filters" popover (v2).

### 3.2 Breadcrumb (height ~36 px)

- Solid `--bg-1` strip; chips separated by faint `›`.
- Updates as user expands or focuses a folder. Clicking any crumb re-centers and zooms to that node.
- Hidden visually (still in DOM) when only the root is focused, to reduce noise.

### 3.3 Canvas

- Pure SVG, full remaining height.
- Pan: drag canvas. Zoom: wheel / pinch / trackpad. Cursor: `grab` → `grabbing`.
- Initial fit = `fitToView()` so the whole tree is visible at load.
- Zoom range 0.2× – 2.4×.

---

## 4. Graph rendering

### 4.1 Node card (220 × 44)

```
┌───────────────────────────────────────┐
│ Title (truncated to 26 chars)      ✓ 🔒│  ← row 1: label + status badges
│ caption · 6 docs                       │  ← row 2: mono sub-text
└───────────────────────────────────────┘
```

- **Folder:** `--bg-2` fill, neutral border. Sub-text shows `<n> child · <m> docs`. Right badge shows `+` (collapsed) or `−` (expanded).
- **Leaf:** `--bg-3` fill, teal-tinted border. Sub-text shows owner or filename. Right badges: `✓` (reviewed, green) and/or `🔒` (internal, amber).

States:
| State | Treatment |
|---|---|
| Resting | Token defaults |
| Hover | 1.8 px stroke in `--accent` (folder) or `--accent-3` (leaf) + matching glow |
| Search match | 1.8 px stroke in `--warn` + warm glow |
| Dim (search active, non-match, non-ancestor) | `opacity: 0.18` |
| Focused/selected | (v2) sustained accent stroke after click |

### 4.2 Connectors

- Tree layout: cubic Bézier S-curve between right edge of parent and left edge of child. Stroke `--border`, 1.2 px.
- Radial layout: shallow Bézier through midpoints. Same stroke.
- When a node is on the active focus path, its incoming link gets `.on-path` (1.8 px, `--accent`) — wired in CSS, applied in v2 once focus state is persistent.

### 4.3 Layouts

- **Tree (default):** horizontal, left-to-right. `nodeSize([62, 310])` so cards never collide and labels stay readable. Matches the SVG sketch you shared.
- **Radial:** root at center, children radiating clockwise. `size([2π, R])` with `R` scaled by tree height. Used for "see everything at once" overviews; trades readability of long titles for density.

Toggle persists in `localStorage` (`amm.layout`). Switching animates positions over ~280 ms; canvas re-fits afterward.

### 4.4 Default expansion rules

- Root + immediate children: expanded.
- Anything at depth ≥ 2: collapsed at first load — keeps initial view scannable.
- Search expands ancestors of any match automatically; clearing search does **not** auto-collapse (preserves user exploration).

---

## 5. Components

### 5.1 Search

- Debounce 80 ms. Fuse.js fuzzy across `meta.title`, `meta.description`, `meta.owner`, `name`, `path` with threshold 0.35 (forgiving but not noisy).
- Behavior: matching leaves get warn-stroke + glow; their ancestor folders are auto-expanded; everything else dims to 18 % opacity. Empty query restores everything.

### 5.2 Filter chips

- Pill buttons, one per boolean flag. Active state inverts color (chip becomes `--accent` solid, text dark).
- Stack with search: filter narrows the search-match set, dims the rest. Combine semantics is AND.
- v2: an Owner dropdown chip and a "Tag" multi-select chip.

### 5.3 Layout toggle

- Two-segment pill. Active segment uses `--bg-3`, inactive is transparent. No icons in v1; labels are short ("Tree" / "Radial"). Keyboard: arrow-left/right when focused.

### 5.4 Breadcrumb

- One row of clickable crumbs joined by `›`. Updates on folder click and on focus events. Hovering a crumb shows `--bg-3`; clicking re-centers and zooms.

### 5.5 Popup (leaf detail)

Layout (560 px max, 92 vw min):

```
Title (18 / 600)
path/to/file.pdf            ← mono, faint

Description paragraph in dim-text, 1.55 line-height.

OWNER       Atul Jadhav <atul.jadhav@adobe.com>
SOURCE      External link
STATUS      [ ✓ Reviewed ]  [ 🔒 Internal ]

                                      [ Close ]  [ Open document ↗ ]
```

- Backdrop: `rgba(5,8,14,0.65)` + 4 px blur. Click backdrop → close. `Esc` → close.
- Title is the metadata title (or filename fallback). Path is verbatim for copy/debugging.
- Badges read clearly in both states: solid color when on, neutral pill when off (so a "not reviewed" doc is *visibly* not reviewed, not just absent).
- Primary CTA is a real `<a target="_blank" rel="noopener">` (no JS click handler) so middle-click and "open in new tab" work as users expect.
- Animations: backdrop fade 180 ms; popup itself rises 8 px + scales 0.98→1 over 200 ms with a soft cubic-bezier.

---

## 6. Motion

| Where | Duration | Easing | Purpose |
|---|---|---|---|
| Node enter / exit | 280 ms | default | New node grows in, removed node fades |
| Layout swap | 280 ms | default | Spatial continuity tree ↔ radial |
| Pan/zoom focus | 500 ms | d3 default | Smooth recenter via breadcrumb click |
| Popup open | 200 ms | `cubic-bezier(.2,.8,.2,1)` | Confident, springy |
| Hover glow | 180 ms | linear | Snappy feedback |
| Search dim/restore | none (instant) | — | Avoid feeling "laggy" while typing |

`prefers-reduced-motion` (v2): drop all transforms, keep opacity transitions only.

---

## 7. Accessibility

v1 baseline:
- Keyboard: Tab cycles topbar controls; Enter on layout buttons toggles; Esc closes popup.
- Popup is `role="dialog" aria-modal="true"`. (v2: trap focus, return focus to invoking node.)
- Color contrast meets WCAG AA on dark canvas.
- Status communicated by **icon + text + color** (✓/🔒 + "Reviewed"/"Internal" + green/amber) — never color alone.

v2 work:
- Full SVG keyboard navigation (arrow keys move between siblings/children, Enter opens leaf popup).
- Live region announces search result count.
- High-contrast token pack toggleable from a settings menu.

---

## 8. Empty / loading / error states

| State | Treatment |
|---|---|
| Loading | Centered "Loading metamodel…" in `--text-dim`. Removed once tree resolves. |
| Empty source folder | Render only the root node + a small banner under the breadcrumb: "No documents found at `<path>`. Add files or `_meta.yml` to populate." |
| Tree fetch error | Loading text becomes `Error: <msg>` in `--danger`. Topbar still functional; clicking the logo retries. |
| Search no-match | Topbar input gets a faint `--warn` outline; dim mode applies but no nodes are highlighted. |
| External link missing | Popup CTA reads "Open file ↗" and points at `localPath` instead of `url`. |

---

## 9. Out of scope for v1 (UI-side parking lot)

- In-app `_meta.yml` editor (drawer with form + write-back through dev server).
- Multi-account switcher in the account chip (dropdown of folders under `Input/`).
- Per-tag filter chips populated from leaf metadata.
- Saved views (focus + filters + layout) shareable via URL.
- Mini-map in the bottom-right for orientation when zoomed in.
- Light theme. (Brand direction is dark-first; light is purely a v2 accessibility lever.)
- Animated path-tracing from root to a focused leaf.

---

## 10. Verification (UI-only)

1. Load app, confirm topbar layout: brand left, controls right, no overflow at 1280×800.
2. Tree visible end-to-end at first paint (auto fit-to-view).
3. Hover a folder → blue glow; hover a leaf → teal glow; click leaf → popup with full metadata.
4. Type "stake" → only matching leaves and their ancestors stay bright; everything else dims.
5. Toggle Reviewed-only → unreviewed leaves dim out of view.
6. Switch Tree → Radial → animation is smooth, fit-to-view triggers at the end.
7. Click a breadcrumb crumb → canvas pans + zooms to that node over 500 ms.
8. Resize window → graph re-fits without clipping.
9. Pop open Stakeholders.md → ✓ badge dim, 🔒 badge solid, primary CTA targets the SharePoint URL with `target="_blank"`.
10. Press `Esc` while popup is open → closes without losing canvas state.
